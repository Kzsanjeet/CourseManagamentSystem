package first;


import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.UIManager;
import javax.swing.JComboBox;
import java.util.regex.*;
import javax.swing.JPasswordField;
import javax.swing.DefaultComboBoxModel;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class registration extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField firstName;
	private JTextField lastName;
	private JTextField email;
	private JPasswordField enterconfirmPassword;
	private JPasswordField enterNewPassword;
	private JComboBox comboBox;

	/**
	 * Launch the application.
	 */
	private void registerUser(String email, String password, String role, String fistname,String lastname) {
        String url = "jdbc:mysql://localhost:3306/CMS";
        String dbUsername = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(url, dbUsername, dbPassword);
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO users (email, password, role) VALUES (?, ?, ?)")) {

            preparedStatement.setString(1, email);
            preparedStatement.setString(2, password);
            preparedStatement.setString(3, role);

            preparedStatement.executeUpdate();

            JOptionPane.showMessageDialog(null, "Registered as " + role);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error occurred during registration.");
        }
    }
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					registration frame = new registration();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public registration() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 751, 499);
		contentPane = new JPanel();
		contentPane.setBackground(UIManager.getColor("List.selectionBackground"));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("    Registration From");
		lblNewLabel.setBounds(272, 45, 221, 35);
		lblNewLabel.setFont(new Font("Noto Serif CJK HK", Font.BOLD, 18));
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("First Name:");
		lblNewLabel_1.setBounds(200, 112, 99, 30);
		lblNewLabel_1.setFont(new Font("SansSerif", Font.BOLD, 15));
		contentPane.add(lblNewLabel_1);
		
		firstName = new JTextField();
		firstName.setBounds(389, 113, 190, 30);
		firstName.setFont(new Font("SansSerif", Font.PLAIN, 15));
		firstName.setForeground(Color.BLACK);
		contentPane.add(firstName);
		firstName.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Last Name:");
		lblNewLabel_2.setBounds(200, 154, 99, 35);
		lblNewLabel_2.setFont(new Font("SansSerif", Font.BOLD, 15));
		contentPane.add(lblNewLabel_2);
		
		lastName = new JTextField();
		lastName.setBounds(389, 154, 190, 29);
		lastName.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lastName.setForeground(Color.BLACK);
		contentPane.add(lastName);
		lastName.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Email:");
		lblNewLabel_3.setBounds(200, 194, 99, 30);
		lblNewLabel_3.setFont(new Font("SansSerif", Font.BOLD, 15));
		contentPane.add(lblNewLabel_3);
		
		email = new JTextField();
		email.setBounds(389, 195, 190, 30);
		email.setFont(new Font("SansSerif", Font.PLAIN, 15));
		email.setForeground(Color.GRAY);
		contentPane.add(email);
		email.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("New Password:");
		lblNewLabel_4.setBounds(200, 226, 137, 41);
		lblNewLabel_4.setFont(new Font("SansSerif", Font.BOLD, 15));
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Confirm Passsword:");
		lblNewLabel_5.setBounds(200, 266, 171, 35);
		lblNewLabel_5.setFont(new Font("SansSerif", Font.BOLD, 15));
		contentPane.add(lblNewLabel_5);
		
		JButton signupbtn = new JButton("Sign Up");
		signupbtn.setBounds(462, 374, 117, 25);
		signupbtn.setFont(new Font("SansSerif", Font.BOLD, 12));
		signupbtn.setBackground(UIManager.getColor("Checkbox.select"));
		signupbtn.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				String firstname = firstName.getText();
				String lastname = lastName.getText();
				String Email = email.getText();
				String newPass = enterNewPassword.getText();
				String confirmPass = enterconfirmPassword.getText();
				String selectMode = (String)comboBox.getSelectedItem();
				
				
				   // Regex for FirstName
                String regexFirst =	"[a-zA-Z]+";
                Pattern Fname = Pattern.compile(regexFirst);
                
                Matcher F1= Fname.matcher(firstname);
                boolean fname = F1.matches();
                
                // Regex for LastName
                String regexLast = "[a-zA-Z]+";
                Pattern Lname = Pattern.compile(regexLast);
                
                Matcher L1= Lname.matcher(lastname);
                boolean lname = L1.matches();
                
              //for email
                String regexEmail =  "^[a-zA-Z0-9_+&-]+(?:\\.[a-zA-Z0-9_+&-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
                Pattern verifyEmail = Pattern.compile(regexEmail);
                
                Matcher eM = verifyEmail.matcher(Email);
                boolean checkEmail = eM.matches();
                
                // Regex for New password
                String regexP = "[a-zA-Z]+";
                Pattern newpass= Pattern.compile(regexP);
                
                Matcher pN = newpass.matcher(newPass);
                boolean passNew = pN.matches();
                
                // Regex for Confirm
				
				if (!firstname.equals("") && !lastname.equals("") && !Email.equals("") && !newPass.equals("") && !confirmPass.equals("")) {
				    // Code to be executed if all conditions are truerlkgjlrjkr
					if(fname==true && lname==true && passNew == true && checkEmail==true && confirmPass.equals(newPass)){
						registerUser(Email,newPass,selectMode,firstname,lastname);
						JOptionPane.showMessageDialog(null,"Success!!");
						
					}else {
						JOptionPane.showMessageDialog(null,"Verification failed");
					}
				}else {
					JOptionPane.showMessageDialog(null,"Value cannot be empty");
				}

			}
		});
		contentPane.add(signupbtn);
		
		enterconfirmPassword = new JPasswordField();
		enterconfirmPassword.setBounds(389, 274, 190, 27);
		contentPane.add(enterconfirmPassword);
		
		enterNewPassword = new JPasswordField();
		enterNewPassword.setBounds(389, 237, 190, 30);
		contentPane.add(enterNewPassword);
		
		comboBox = new JComboBox();
		comboBox.setBounds(387, 313, 192, 24);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"[--Select Mode--]", "Admin", "Student", "Tutor", "", "", "", "", ""}));
		contentPane.add(comboBox);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.setBounds(200, 374, 117, 25);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				hello h1 = new hello(); //creating obj for login page
				h1.setVisible(true); //it goes to login page
				dispose(); // it override old page
			}
		});
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_6 = new JLabel("Select Mode");
		lblNewLabel_6.setBounds(200, 313, 108, 24);
		lblNewLabel_6.setFont(new Font("SansSerif", Font.BOLD, 15));
		contentPane.add(lblNewLabel_6);
	}
}
